
# DiffusionRgqd - NEWS
__DiffusionRgqd__ is available on CRAN and GitHub.

Check out [DiffusionRgqd](https://github.com/eta21/DiffusionRgqd) for the package source files and [DiffusionRgqd-Downloads](https://github.com/eta21/DiffusionRgqd-Downloads) for example scripts and other downloadable content.

# v0.1.0
Initial verision of __DiffusionRgqd__ uploaded to CRAN and GitHub.